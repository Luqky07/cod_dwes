<?php
//emple.inc.php

define('HOST', 'localhost');
define('BD', 'gesventa');
define('USER', 'root');
define('PWD', '');
define('CHRST', 'utf8');
